package test3;

public class VoidReturn {
    public void foo() {}
}
