package test3;

public class SetModifiers {
    public int m;
    public static final class A {
        public int a;
    }
}
