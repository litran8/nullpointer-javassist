package test.javassist.tools;

public class DummyClass {

    private String dummyString = "dummyStringValue";

    public void dummyMethod(){}
}
