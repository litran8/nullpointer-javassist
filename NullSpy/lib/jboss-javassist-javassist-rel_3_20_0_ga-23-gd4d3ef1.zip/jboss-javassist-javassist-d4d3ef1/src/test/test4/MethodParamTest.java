package test4;

public class MethodParamTest {
    public void test(int i, String s) {}
}
