package test1;

public class FieldMod {
    private String text;
    public int i;
}
