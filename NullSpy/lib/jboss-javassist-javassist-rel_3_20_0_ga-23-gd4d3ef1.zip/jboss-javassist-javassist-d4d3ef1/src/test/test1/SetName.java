package test1;

public class SetName {
    public int i;
    public int foo(SetName sn) { return 1; }
}
