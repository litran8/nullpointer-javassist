package test2;

public class Finally {
    int a = 0;
    String s = null;
    double b = 1.0;

    public void update() {
        a = s.length();
        b++;
    }
}
